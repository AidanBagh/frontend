export const API_URL = 'https://eshop.devsrwanda.com';
export const API_ENDPOINTS = {
    products: '/api/products',
    auth: {
        login: '/api/auth/login'
    },
    cart: {
        add: '/api/cart/add',
        update: '/api/cart/update',
        remove: '/api/cart/remove',
        get: (userId) => `/api/cart/${userId}`
    }
    // Add other endpoints here as needed
};

export const getApiUrl = (endpoint) => {
    return `${API_URL}${endpoint}`;
};

export const getImageUrl = (imagePath) => {
    if (!imagePath) return '';
    // Remove the leading slash if it exists
    const cleanPath = imagePath.startsWith('/') ? imagePath.slice(1) : imagePath;
    return `${API_URL}/${cleanPath}`;
}; 