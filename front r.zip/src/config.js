export const API_URL = 'http://localhost:5000';
export const getImageUrl = (imagePath) => {
    if (!imagePath) return '';
    // Remove the leading slash if it exists
    const cleanPath = imagePath.startsWith('/') ? imagePath.slice(1) : imagePath;
    return `${API_URL}/${cleanPath}`;
}; 