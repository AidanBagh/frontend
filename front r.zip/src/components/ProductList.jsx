import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { API_URL, getImageUrl } from '../config';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { cart, addToCart } = useCart();
  const [quantities, setQuantities] = useState({});

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(`${API_URL}/api/products`);
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        const data = await response.json();
        setProducts(data.produits);
        
        // Initialize quantities
        const initialQuantities = {};
        data.produits.forEach(product => {
          initialQuantities[product.id] = 1;
        });
        setQuantities(initialQuantities);
      } catch (error) {
        setError('Error loading products');
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleQuantityChange = (productId, newQuantity) => {
    const product = products.find(p => p.id === productId);
    if (newQuantity > 0 && newQuantity <= product.stock) {
      setQuantities(prev => ({
        ...prev,
        [productId]: newQuantity
      }));
    }
  };

  const handleAddToCart = async (product) => {
    try {
      const quantity = quantities[product.id];
      if (quantity > product.stock) {
        setError(`Only ${product.stock} items available`);
        setTimeout(() => setError(null), 3000);
        return;
      }
      await addToCart(product, quantity);
      // Reset quantity after adding to cart
      setQuantities(prev => ({
        ...prev,
        [product.id]: 1
      }));
    } catch (error) {
      setError(error.message);
      setTimeout(() => setError(null), 3000);
    }
  };

  const isInCart = (productId) => {
    return cart.some(item => item.productId === productId);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-red-500">{error}</div>
      </div>
    );
  }

  return (
    <div className="bg-white">
      <div className="max-w-2xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">
        <h2 className="text-2xl font-extrabold text-gray-900 mb-6">Our Products</h2>
        <div className="grid grid-cols-1 gap-y-10 sm:grid-cols-2 gap-x-6 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
          {products.map((product) => (
            <div key={product.id} className="group relative">
              <div className="w-full aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg overflow-hidden xl:aspect-w-7 xl:aspect-h-8">
                <img
                  src={getImageUrl(product.image)}
                  alt={product.nom}
                  className="w-full h-full object-center object-cover group-hover:opacity-75"
                />
              </div>
              <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm text-gray-700">{product.nom}</h3>
                  <p className="mt-1 text-sm text-gray-500">{product.description}</p>
                </div>
                <p className="text-sm font-medium text-gray-900">{product.prix.toLocaleString()} FCFA</p>
              </div>
              <div className="mt-2">
                {!isInCart(product.id) && (
                  <div className="flex items-center mb-2">
                    <label htmlFor={`quantity-${product.id}`} className="mr-2 text-sm text-gray-600">
                      Quantity:
                    </label>
                    <div className="flex items-center border border-gray-300 rounded">
                      <button
                        type="button"
                        onClick={() => handleQuantityChange(product.id, quantities[product.id] - 1)}
                        className="px-2 py-1 text-gray-600 hover:text-gray-800"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        id={`quantity-${product.id}`}
                        min="1"
                        max={product.stock}
                        value={quantities[product.id]}
                        onChange={(e) => handleQuantityChange(product.id, parseInt(e.target.value) || 1)}
                        className="w-16 text-center border-x border-gray-300 py-1"
                      />
                      <button
                        type="button"
                        onClick={() => handleQuantityChange(product.id, quantities[product.id] + 1)}
                        className="px-2 py-1 text-gray-600 hover:text-gray-800"
                      >
                        +
                      </button>
                    </div>
                  </div>
                )}
                <button
                  onClick={() => handleAddToCart(product)}
                  disabled={isInCart(product.id)}
                  className={`w-full py-2 px-4 rounded-md text-sm font-medium ${
                    isInCart(product.id)
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {isInCart(product.id) ? 'In Cart' : 'Add to Cart'}
                </button>
              </div>
              <p className="mt-1 text-sm text-gray-500">Stock: {product.stock}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductList; 