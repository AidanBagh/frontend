const fs = require('fs').promises;
const path = require('path');

const DB_PATH = path.join(__dirname, '../../database/db.json');

const readDatabase = async () => {
  const data = await fs.readFile(DB_PATH, 'utf8');
  return JSON.parse(data);
};

const getAllProducts = async (req, res) => {
  try {
    const db = await readDatabase();
    res.json({ produits: db.produits });
  } catch (error) {
    console.error('Error getting products:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const getProductById = async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const db = await readDatabase();
    
    const product = db.produits.find(p => p.id === productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    console.error('Error getting product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = {
  getAllProducts,
  getProductById
}; 