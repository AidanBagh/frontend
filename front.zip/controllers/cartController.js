const fs = require('fs').promises;
const path = require('path');

const DB_PATH = path.join(__dirname, '../../database/db.json');

const readDatabase = async () => {
  const data = await fs.readFile(DB_PATH, 'utf8');
  return JSON.parse(data);
};

const writeDatabase = async (data) => {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 4));
};

const getCart = async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const db = await readDatabase();
    
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Initialize cart if it doesn't exist
    if (!user.panier) {
      user.panier = [];
    }

    // Convert cart items to objects with quantities
    const cartItems = user.panier.map(item => {
      if (typeof item === 'object') {
        return item;
      } else if (typeof item === 'number') {
        return { productId: item, quantity: 1 };
      }
      return null;
    }).filter(Boolean);

    // Update user's cart in database with new format
    const userIndex = db.users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      db.users[userIndex].panier = cartItems;
      await writeDatabase(db);
    }

    res.json({ panier: cartItems });
  } catch (error) {
    console.error('Error getting cart:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const addToCart = async (req, res) => {
  try {
    const { userId, productId, quantity = 1 } = req.body;
    const db = await readDatabase();
    
    // Find user
    const userIndex = db.users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if product exists and has enough stock
    const product = db.produits.find(p => p.id === productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    if (quantity > product.stock) {
      return res.status(400).json({ message: `Only ${product.stock} items available` });
    }

    // Convert simple array to array of objects if needed
    if (!Array.isArray(db.users[userIndex].panier)) {
      db.users[userIndex].panier = [];
    }
    db.users[userIndex].panier = db.users[userIndex].panier.map(item => {
      return typeof item === 'object' ? item : { productId: item, quantity: 1 };
    });

    // Check if product is already in cart
    const cartItemIndex = db.users[userIndex].panier.findIndex(item => item.productId === productId);
    if (cartItemIndex === -1) {
      // Add new item
      db.users[userIndex].panier.push({ productId, quantity });
    } else {
      // Update quantity
      const newQuantity = db.users[userIndex].panier[cartItemIndex].quantity + quantity;
      if (newQuantity > product.stock) {
        return res.status(400).json({ message: `Only ${product.stock} items available` });
      }
      db.users[userIndex].panier[cartItemIndex].quantity = newQuantity;
    }

    await writeDatabase(db);
    res.json({ panier: db.users[userIndex].panier });
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const updateQuantity = async (req, res) => {
  try {
    const { userId, productId, quantity } = req.body;
    const db = await readDatabase();
    
    // Find user
    const userIndex = db.users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if product exists and has enough stock
    const product = db.produits.find(p => p.id === productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    if (quantity > product.stock) {
      return res.status(400).json({ message: `Only ${product.stock} items available` });
    }

    // Convert simple array to array of objects if needed
    if (!Array.isArray(db.users[userIndex].panier)) {
      db.users[userIndex].panier = [];
    }
    db.users[userIndex].panier = db.users[userIndex].panier.map(item => {
      return typeof item === 'object' ? item : { productId: item, quantity: 1 };
    });

    // Find and update item quantity
    const cartItemIndex = db.users[userIndex].panier.findIndex(item => item.productId === productId);
    if (cartItemIndex === -1) {
      return res.status(404).json({ message: 'Item not found in cart' });
    }

    db.users[userIndex].panier[cartItemIndex].quantity = quantity;
    await writeDatabase(db);
    res.json({ panier: db.users[userIndex].panier });
  } catch (error) {
    console.error('Error updating cart:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const removeFromCart = async (req, res) => {
  try {
    const { userId, productId } = req.body;
    const db = await readDatabase();
    
    // Find user
    const userIndex = db.users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Convert simple array to array of objects if needed
    if (!Array.isArray(db.users[userIndex].panier)) {
      db.users[userIndex].panier = [];
    }
    db.users[userIndex].panier = db.users[userIndex].panier.map(item => {
      return typeof item === 'object' ? item : { productId: item, quantity: 1 };
    });

    // Remove product from cart
    db.users[userIndex].panier = db.users[userIndex].panier.filter(item => item.productId !== productId);
    await writeDatabase(db);

    res.json({ panier: db.users[userIndex].panier });
  } catch (error) {
    console.error('Error removing from cart:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = {
  getCart,
  addToCart,
  removeFromCart,
  updateQuantity
}; 